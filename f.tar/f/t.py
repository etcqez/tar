import getpass

pwd=getpass.getpass()
print(pwd)
