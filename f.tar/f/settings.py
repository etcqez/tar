'''
web frame的配置文件
'''

frame_ip='0.0.0.0'
frame_port=8080

DEBUG=True

# 网页存放位置
STATIC_DIR='./blog/hugo/public'
