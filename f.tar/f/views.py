import time

def show_time():
    return time.ctime()

def hello():
    return 'Hello World'

def bye():
    return "Good Bye" 
